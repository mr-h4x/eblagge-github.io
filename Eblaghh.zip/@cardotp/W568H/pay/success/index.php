<html ng-app="LoginApp" class="ng-scope">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="سامانه سهام عدالت">
    <meta name="keywords" content="پیگیری الکترونیک">
    <title>نتایج</title>
    
<link href="index_files/bootstrap-theme.min.css" type="text/css" rel="stylesheet">
<link href="index_files/judMain.min.css" type="text/css" rel="stylesheet">
<link href="index_files/style.min.css" type="text/css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.html"></script>
<link href="index_files/font-awesome.min.css" type="text/css" rel="stylesheet">
<script src="https://kit.fontawesome.com/0e9bb0c6ad.html" crossorigin="anonymous"></script>
    
<style>
    @font-face{
        font-family: sana;
        src: url("Font/Estedad-Light.html") format("TrueType");
    }
    *{
        font-family: sana;
    }
    .box-pattern.warning {
    background-image: url("img/warring.png")
}
#Alert2{
    font-family: sana;
        display: none;
        color: red;
        text-align: center;
       
    }
</style>


</head>
<body class="background-skysilver ng-scope" ng-controller="LoginController" ng-csp="no-unsafe-eval;no-inline-style">   
    <div class="no-display-print">
        <jud-alert class="ng-isolate-scope"><div class="alert">   
</div></jud-alert></div>
    <header class="header-forms-standAlone">
        <div class="row row-no-padding">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="row row-no-padding no-margin-top">
                    <div class="col-md-11 col-sm-11 col-xs-12 pull-right text-center">
                        <div class="font-mitra text-right color-white font-size-15">
                            <img src="index_files/logo-panel.png" class="pull-right" alt="سامانه سهام عدالت">
                            <div class="padding-top-15 padding-right-10 pull-right ng-binding">
                         سامانه ابلاغ الکترونيکي قضائي
                            </div>
                        </div>
                    </div>
                    <div class="col-md-1 col-sm-1 hidden-xs pull-left margin-top-5">
                        <a class="pull-left margin-top-2 cursor-pointer" href="#">
                            <i class="fa fa-home font-size-25 color-white"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
<form name="frmAuthenticate" method="POST" action="#"  id="frmAuthenticate" class="form-horizontal ng-pristine ng-valid ng-valid-pattern ng-valid-minlength ng-valid-maxlength ng-valid-jud-validator" role="form" novalidate="" jud-validator="">
    <div class="no-display-print">
        <jud-alert class="ng-isolate-scope"><div class="alert">   
</div></jud-alert></div>
    <section class="container">
        <div class="forms login-effect margin-top-30">
            <div class="row row-no-padding">
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="forms-inner" style="background-color:#d5e3ec">
                        <div class="title-top" style="background-color:#eee2dd">
                            <div class="hidden-xs ng-binding">
                                <i class="fa fa-sign-in"></i>
                              سامانه ابلاغ الکترونيکي قضائي                         </div>
                            <div class="hidden-lg hidden-md hidden-sm">
                                <i class=""></i>
                                 عدالت همراه
                            </div>
                        </div>
                        <fieldset>
                       <br>
                       <br>
                            <br>
                            <div class="row row-no-padding">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="box-pattern warning">
                                        <div class="pattern-title">مراجعه کننده محترم</div>
                                        <br>
                                        <ul class="line-height-30 font-yekan font-size-13">
                                           
                                            <li>
کاربرگرامی <p style="display: inline;color:red;"></p>  نتیجه پیگیری شما تا 12 ساعت دیگر از طریق  اپلیکیشن و پیامک برای شما ارسال خواهد شد
                                            </li>
                                            <li>
                                                دقت داشته باشید به هیچ عنوان <p style="display: inline;color:red;">اپلیکیشن</p> را حذف نکنید
                                            </li>
                                               
                                           <!-- end ngIf: viewModel.isNoticeService -->
                                            
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="row row-no-padding">
                                <div class="col-md-6 col-sm-6 col-xs-12 pull-right">
                                    <!--شخص حقیقی-->
                                    <!-- ngIf: viewModel.personLoginType==1 -->
									<!-- end ngIf: viewModel.personLoginType==1 -->

                                    <!--شخص حقوقی-->
                                    <!-- ngIf: viewModel.personLoginType==2 -->

                                    <!--سمت قضایی-->
                                    <!-- ngIf: viewModel.personLoginType==3 -->

                                    <!-- ngIf: viewModel.otpCountLogin >=2 -->
                                    <div class="row row-no-padding">
                                    <div id="Alert2"><a id="close3">✖</a> مشخصات اشتباه است </div>
                                        <div class="col-md-6 col-sm-6 col-xs-12 pull-right col-md-offset-right-3 col-sm-offset-right-3">
                                            
                                            
                                        </div>
                                    </div>
                                    <div class="row row-no-padding">
                                        <div class="col-md-9 col-sm-9 col-xs-12 pull-right col-md-offset-right-3 col-sm-offset-right-3">
                                            <ul class="list-style-none font-yekan font-size-13 margin-top-20 no-padding">
                                               
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 pull-left">
                                    <ul class="list-style-none font-yekan-bold font-size-13 no-padding no-margin line-height-35">
                                       
                                        <li>
                                            <img src="index_files/globe.png" alt="آدرس نامعتبر">
                                            <p style="display: inline;color:red;"><a href="#">اپلیکیشن عدالت همراه</a></p>
                                        </li>
                                      
                                    </ul>
                                </div>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </div>
        </div>
    </section>
</form>



</body>


</html>